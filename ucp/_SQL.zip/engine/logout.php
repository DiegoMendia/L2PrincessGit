<?php

if(!$indexing) { exit; }

require_once('private/classes/classAccess.php');
Access::logout();
