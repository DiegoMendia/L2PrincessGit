<?php

$uniqueKey = 'MZN9BA7TSVA9UIIAI67A75345A0L12';

$admref_ucp = '../';
