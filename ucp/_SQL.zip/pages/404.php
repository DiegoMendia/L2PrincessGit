<?php if(!$indexing) { exit; } ?>

<ul class="breadcrumb">
	<li><a href="./"><i class='fa fa-home'></i> Home</a></li>
	<li>404 - NOT FOUND</li>
</ul>

<h1>404 - NOT FOUND</h1>

<div class='pddInner'><?php echo $LANG[39005]; ?></div>
